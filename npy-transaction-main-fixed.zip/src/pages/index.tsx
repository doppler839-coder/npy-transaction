import React from 'react'

const index = () => {
  return (
    <div><TransactionForm /></div>
  )
}

export default index